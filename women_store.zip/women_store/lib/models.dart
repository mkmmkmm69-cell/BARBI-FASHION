class Product {
  final int? id;
  final String name;
  final String category;
  final String description;
  final String sizes;
  final String colors;
  final String imagePath;
  final double price;
  final int stock;

  const Product({
    this.id,
    required this.name,
    required this.category,
    required this.price,
    this.description = '',
    this.sizes = '',
    this.colors = '',
    this.imagePath = '',
    this.stock = 0,
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'category': category,
        'description': description,
        'sizes': sizes,
        'colors': colors,
        'image_path': imagePath,
        'price': price,
        'stock': stock,
      };

  factory Product.fromMap(Map<String, Object?> m) => Product(
        id: m['id'] as int?,
        name: m['name'] as String,
        category: m['category'] as String,
        description: (m['description'] as String?) ?? '',
        sizes: (m['sizes'] as String?) ?? '',
        colors: (m['colors'] as String?) ?? '',
        imagePath: (m['image_path'] as String?) ?? '',
        price: (m['price'] as num).toDouble(),
        stock: (m['stock'] as int?) ?? 0,
      );
}
