import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// PBKDF2-HMAC-SHA256 (يعمل في isolate حتى لا يجمّد الواجهة)
List<int> _derive(List<Object> a) {
  final pw = a[0] as String;
  final salt = a[1] as List<int>;
  final iter = a[2] as int;
  final hmac = Hmac(sha256, utf8.encode(pw));
  var u = hmac.convert([...salt, 0, 0, 0, 1]).bytes;
  final out = List<int>.from(u);
  for (var i = 1; i < iter; i++) {
    u = hmac.convert(u).bytes;
    for (var j = 0; j < out.length; j++) {
      out[j] ^= u[j];
    }
  }
  return out;
}

class Auth {
  // يُخزَّن داخل Android Keystore (تشفير عتادي)
  static const _s = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const _iterations = 60000;
  static bool loggedIn = false;

  static Future<bool> isSetup() async => (await _s.read(key: 'owner_user')) != null;

  static Future<String> _hash(String pw, List<int> salt) async =>
      base64.encode(await compute(_derive, <Object>[pw, salt, _iterations]));

  static bool _eq(String a, String b) {
    if (a.length != b.length) return false;
    var r = 0;
    for (var i = 0; i < a.length; i++) {
      r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return r == 0;
  }

  static Future<void> _store(String user, String pw) async {
    final rnd = Random.secure();
    final salt = List<int>.generate(16, (_) => rnd.nextInt(256));
    await _s.write(key: 'owner_user', value: user.trim().toLowerCase());
    await _s.write(key: 'owner_salt', value: base64.encode(salt));
    await _s.write(key: 'owner_hash', value: await _hash(pw, salt));
  }

  static Future<void> setup(String user, String pw) async {
    await _store(user, pw);
    loggedIn = true;
  }

  static Future<bool> _passwordOk(String pw) async {
    final salt = base64.decode(await _s.read(key: 'owner_salt') ?? '');
    final stored = await _s.read(key: 'owner_hash') ?? '';
    return _eq(await _hash(pw, salt), stored);
  }

  /// يرجع null عند النجاح، أو رسالة الخطأ
  static Future<String?> login(String user, String pw) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final lockUntil = int.tryParse(await _s.read(key: 'lock_until') ?? '') ?? 0;
    if (now < lockUntil) {
      return 'محاولات كثيرة. حاول بعد ${((lockUntil - now) / 1000).ceil()} ثانية';
    }
    final u = await _s.read(key: 'owner_user');
    final ok = u == user.trim().toLowerCase() && await _passwordOk(pw);
    if (ok) {
      await _s.delete(key: 'fails');
      await _s.delete(key: 'lock_until');
      loggedIn = true;
      return null;
    }
    final fails = (int.tryParse(await _s.read(key: 'fails') ?? '') ?? 0) + 1;
    await _s.write(key: 'fails', value: '$fails');
    if (fails >= 5) {
      final secs = min(30 * (1 << min(fails - 5, 5)), 900);
      await _s.write(key: 'lock_until', value: '${now + secs * 1000}');
      return 'تم القفل مؤقتاً لمدة $secs ثانية بسبب محاولات خاطئة';
    }
    return 'اسم المستخدم أو كلمة المرور غير صحيحة';
  }

  static Future<String?> changePassword(String oldPw, String newPw) async {
    if (!await _passwordOk(oldPw)) return 'كلمة المرور الحالية غير صحيحة';
    final u = await _s.read(key: 'owner_user') ?? '';
    await _store(u, newPw);
    return null;
  }

  static void logout() => loggedIn = false;
}
