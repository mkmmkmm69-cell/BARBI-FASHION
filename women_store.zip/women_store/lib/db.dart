import 'package:path/path.dart' as pth;
import 'package:sqflite/sqflite.dart';
import 'models.dart';

class Db {
  Db._();
  static final Db i = Db._();
  Database? _db;

  Future<Database> get _database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = pth.join(await getDatabasesPath(), 'store.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (d, v) => d.execute('''
        CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          category TEXT NOT NULL,
          description TEXT,
          sizes TEXT,
          colors TEXT,
          image_path TEXT,
          price REAL NOT NULL,
          stock INTEGER DEFAULT 0
        )'''),
    );
  }

  // كل الاستعلامات بمعاملات (?) لمنع SQL Injection
  Future<List<Product>> list({String q = '', String? category}) async {
    final d = await _database;
    final where = <String>[];
    final args = <Object>[];
    if (q.trim().isNotEmpty) {
      where.add('name LIKE ?');
      args.add('%${q.trim()}%');
    }
    if (category != null) {
      where.add('category = ?');
      args.add(category);
    }
    final rows = await d.query(
      'products',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'id DESC',
    );
    return rows.map(Product.fromMap).toList();
  }

  Future<void> insert(Product p) async => (await _database).insert('products', p.toMap());

  Future<void> update(Product p) async =>
      (await _database).update('products', p.toMap(), where: 'id = ?', whereArgs: [p.id]);

  Future<void> delete(int id) async =>
      (await _database).delete('products', where: 'id = ?', whereArgs: [id]);
}
