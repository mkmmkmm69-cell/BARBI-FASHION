import 'dart:io';
import 'package:flutter/material.dart';

const kCategories = [
  'فساتين', 'عبايات', 'بلوزات', 'تنانير', 'بناطيل', 'حجاب', 'ملابس نوم', 'أخرى',
];

const kCurrency = 'د.ع'; // غيّرها لعملتك

String money(double v) {
  final s = v.toStringAsFixed(v == v.truncateToDouble() ? 0 : 2);
  final parts = s.split('.');
  final buf = StringBuffer();
  for (var i = 0; i < parts[0].length; i++) {
    if (i > 0 && (parts[0].length - i) % 3 == 0) buf.write(',');
    buf.write(parts[0][i]);
  }
  final frac = parts.length > 1 ? '.${parts[1]}' : '';
  return '$buf$frac $kCurrency';
}

/// يحوّل الأرقام العربية (٠-٩) إلى إنجليزية
String normDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (ch == '٫') {
      b.write('.');
    } else if (ch == '٬' || ch == ',') {
      continue;
    } else {
      b.write(ch);
    }
  }
  return b.toString().trim();
}

Future<void> safeDelete(String path) async {
  try {
    if (path.isNotEmpty) await File(path).delete();
  } catch (_) {}
}

class ProductImage extends StatelessWidget {
  final String path;
  const ProductImage(this.path, {super.key});

  @override
  Widget build(BuildContext context) {
    if (path.isEmpty || !File(path).existsSync()) {
      return Container(
        color: Colors.pink.shade50,
        child: const Center(child: Icon(Icons.checkroom, size: 48, color: Colors.pinkAccent)),
      );
    }
    return Image.file(File(path), fit: BoxFit.cover, width: double.infinity, height: double.infinity);
  }
}
