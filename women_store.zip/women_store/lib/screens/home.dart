import 'package:flutter/material.dart';
import '../auth.dart';
import '../db.dart';
import '../models.dart';
import '../widgets.dart';
import 'admin.dart';
import 'auth_screens.dart';
import 'detail.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _q = TextEditingController();
  String? _cat;
  List<Product> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final r = await Db.i.list(q: _q.text, category: _cat);
    if (!mounted) return;
    setState(() {
      _items = r;
      _loading = false;
    });
  }

  Future<void> _owner() async {
    final nav = Navigator.of(context);
    final Widget next = Auth.loggedIn
        ? const AdminScreen()
        : OwnerAuthScreen(setup: !(await Auth.isSetup()));
    await nav.push(MaterialPageRoute(builder: (_) => next));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: AppBar(
        title: const Text('متجر الأزياء النسائية'),
        actions: [
          IconButton(tooltip: 'دخول المالك', icon: const Icon(Icons.lock_outline), onPressed: _owner),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: TextField(
            controller: _q,
            onChanged: (_) => _load(),
            decoration: InputDecoration(
              hintText: 'ابحث عن منتج...',
              prefixIcon: const Icon(Icons.search),
              isDense: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            children: [
              for (final c in <String?>[null, ...kCategories])
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(c ?? 'الكل'),
                    selected: _cat == c,
                    onSelected: (_) {
                      setState(() => _cat = c);
                      _load();
                    },
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _items.isEmpty
                  ? const Center(child: Text('لا توجد منتجات'))
                  : GridView.builder(
                      padding: const EdgeInsets.all(12),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.68,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: _items.length,
                      itemBuilder: (_, i) {
                        final p = _items[i];
                        return Card(
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => DetailScreen(product: p)),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Expanded(
                                child: Stack(fit: StackFit.expand, children: [
                                  ProductImage(p.imagePath),
                                  if (p.stock <= 0)
                                    Positioned(
                                      top: 8,
                                      right: 8,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: Colors.black54,
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: const Text('نفدت الكمية',
                                            style: TextStyle(color: Colors.white, fontSize: 11)),
                                      ),
                                    ),
                                ]),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(p.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.w600)),
                                  const SizedBox(height: 2),
                                  Text(money(p.price),
                                      style: TextStyle(color: primary, fontWeight: FontWeight.bold)),
                                ]),
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}
