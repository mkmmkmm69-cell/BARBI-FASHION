import 'package:flutter/material.dart';
import '../auth.dart';
import 'admin.dart';

class OwnerAuthScreen extends StatefulWidget {
  final bool setup;
  const OwnerAuthScreen({super.key, required this.setup});
  @override
  State<OwnerAuthScreen> createState() => _OwnerAuthScreenState();
}

class _OwnerAuthScreenState extends State<OwnerAuthScreen> {
  final _form = GlobalKey<FormState>();
  final _u = TextEditingController();
  final _p = TextEditingController();
  final _p2 = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _err;

  @override
  void dispose() {
    _u.dispose();
    _p.dispose();
    _p2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _err = null;
    });
    String? err;
    if (widget.setup) {
      await Auth.setup(_u.text, _p.text);
    } else {
      err = await Auth.login(_u.text, _p.text);
    }
    if (!mounted) return;
    if (err != null) {
      setState(() {
        _busy = false;
        _err = err;
      });
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final setup = widget.setup;
    return Scaffold(
      appBar: AppBar(title: Text(setup ? 'إنشاء حساب المالك' : 'دخول المالك')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _form,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.storefront, size: 64),
              const SizedBox(height: 8),
              if (setup)
                const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text('أول مرة؟ أنشئ اسم مستخدم وكلمة مرور. هذا الحساب هو الوحيد الذي يعدّل المنتجات.',
                      textAlign: TextAlign.center),
                ),
              TextFormField(
                controller: _u,
                decoration: const InputDecoration(labelText: 'اسم المستخدم', border: OutlineInputBorder()),
                validator: (v) => (v == null || v.trim().length < 3) ? '3 أحرف على الأقل' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _p,
                obscureText: _hide,
                decoration: InputDecoration(
                  labelText: 'كلمة المرور',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _hide = !_hide),
                  ),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'مطلوب';
                  if (setup && v.length < 8) return '8 أحرف على الأقل';
                  return null;
                },
              ),
              if (setup) ...[
                const SizedBox(height: 12),
                TextFormField(
                  controller: _p2,
                  obscureText: _hide,
                  decoration: const InputDecoration(labelText: 'تأكيد كلمة المرور', border: OutlineInputBorder()),
                  validator: (v) => v != _p.text ? 'غير متطابقة' : null,
                ),
              ],
              if (_err != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(setup ? 'إنشاء الحساب' : 'دخول'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});
  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _old = TextEditingController();
  final _new = TextEditingController();
  final _new2 = TextEditingController();
  bool _busy = false;
  String? _err;

  @override
  void dispose() {
    _old.dispose();
    _new.dispose();
    _new2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _err = null;
    });
    final err = await Auth.changePassword(_old.text, _new.text);
    if (!mounted) return;
    if (err != null) {
      setState(() {
        _busy = false;
        _err = err;
      });
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تغيير كلمة المرور')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تغيير كلمة المرور')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _form,
          child: Column(children: [
            TextFormField(
              controller: _old,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور الحالية', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.isEmpty) ? 'مطلوب' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _new,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور الجديدة', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.length < 8) ? '8 أحرف على الأقل' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _new2,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'تأكيد الجديدة', border: OutlineInputBorder()),
              validator: (v) => v != _new.text ? 'غير متطابقة' : null,
            ),
            if (_err != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(onPressed: _busy ? null : _submit, child: const Text('حفظ')),
            ),
          ]),
        ),
      ),
    );
  }
}
