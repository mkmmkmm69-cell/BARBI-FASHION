import 'package:flutter/material.dart';
import '../models.dart';
import '../widgets.dart';

class DetailScreen extends StatelessWidget {
  final Product product;
  const DetailScreen({super.key, required this.product});

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('$k: ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(v)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final p = product;
    final t = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(p.name)),
      body: ListView(children: [
        AspectRatio(aspectRatio: 1, child: ProductImage(p.imagePath)),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.name, style: t.textTheme.headlineSmall),
            const SizedBox(height: 6),
            Text(money(p.price),
                style: t.textTheme.titleLarge?.copyWith(color: t.colorScheme.primary, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              Chip(label: Text(p.category)),
              Chip(label: Text(p.stock > 0 ? 'متوفر (${p.stock})' : 'نفدت الكمية')),
            ]),
            if (p.sizes.isNotEmpty) _row('المقاسات', p.sizes),
            if (p.colors.isNotEmpty) _row('الألوان', p.colors),
            if (p.description.isNotEmpty) ...[
              const SizedBox(height: 14),
              Text(p.description),
            ],
          ]),
        ),
      ]),
    );
  }
}
