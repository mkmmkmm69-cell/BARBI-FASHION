import 'package:flutter/material.dart';
import '../auth.dart';
import '../db.dart';
import '../models.dart';
import '../widgets.dart';
import 'auth_screens.dart';
import 'edit.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  List<Product> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Db.i.list();
    if (!mounted) return;
    setState(() {
      _items = r;
      _loading = false;
    });
  }

  Future<void> _edit([Product? p]) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => EditScreen(product: p)));
    _load();
  }

  Future<void> _delete(Product p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('حذف المنتج'),
          content: Text('هل تريد حذف "${p.name}" نهائياً؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await Db.i.delete(p.id!);
    await safeDelete(p.imagePath);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('لوحة المالك (${_items.length})'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'pw') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ChangePasswordScreen()));
              } else {
                Auth.logout();
                Navigator.pop(context);
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'pw', child: Text('تغيير كلمة المرور')),
              PopupMenuItem(value: 'out', child: Text('تسجيل الخروج')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add),
        label: const Text('إضافة منتج'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('لا توجد منتجات. اضغط "إضافة منتج"'))
              : ListView.separated(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final p = _items[i];
                    return ListTile(
                      leading: SizedBox(
                        width: 56,
                        height: 56,
                        child: ClipRRect(borderRadius: BorderRadius.circular(8), child: ProductImage(p.imagePath)),
                      ),
                      title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${p.category} • ${money(p.price)} • كمية: ${p.stock}'),
                      onTap: () => _edit(p),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _delete(p),
                      ),
                    );
                  },
                ),
    );
  }
}
