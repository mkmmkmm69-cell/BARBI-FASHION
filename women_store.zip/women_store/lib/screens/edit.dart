import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as pth;
import 'package:path_provider/path_provider.dart';
import '../db.dart';
import '../models.dart';
import '../widgets.dart';

class EditScreen extends StatefulWidget {
  final Product? product;
  const EditScreen({super.key, this.product});
  @override
  State<EditScreen> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.product?.name);
  late final _price = TextEditingController(
      text: widget.product == null ? '' : widget.product!.price.toString().replaceAll(RegExp(r'\.0$'), ''));
  late final _stock = TextEditingController(text: widget.product?.stock.toString() ?? '');
  late final _sizes = TextEditingController(text: widget.product?.sizes);
  late final _colors = TextEditingController(text: widget.product?.colors);
  late final _desc = TextEditingController(text: widget.product?.description);
  late String _cat = widget.product?.category ?? kCategories.first;
  late String _img = widget.product?.imagePath ?? '';
  bool _saving = false;

  String get _original => widget.product?.imagePath ?? '';

  @override
  void dispose() {
    for (final c in [_name, _price, _stock, _sizes, _colors, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pick(ImageSource src) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1200, imageQuality: 80);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = pth.join(dir.path, 'img_${DateTime.now().microsecondsSinceEpoch}${pth.extension(x.path)}');
    await File(x.path).copy(dest);
    if (!mounted) return;
    setState(() {
      if (_img.isNotEmpty && _img != _original) safeDelete(_img); // صورة مؤقتة سابقة
      _img = dest;
    });
  }

  void _pickSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('من المعرض'),
              onTap: () {
                Navigator.pop(context);
                _pick(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('التقاط صورة'),
              onTap: () {
                Navigator.pop(context);
                _pick(ImageSource.camera);
              },
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final prod = Product(
      id: widget.product?.id,
      name: _name.text.trim(),
      category: _cat,
      price: double.parse(normDigits(_price.text)),
      stock: int.tryParse(normDigits(_stock.text)) ?? 0,
      sizes: _sizes.text.trim(),
      colors: _colors.text.trim(),
      description: _desc.text.trim(),
      imagePath: _img,
    );
    if (prod.id == null) {
      await Db.i.insert(prod);
    } else {
      await Db.i.update(prod);
    }
    if (_original.isNotEmpty && _original != _img) await safeDelete(_original);
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isNew = widget.product == null;
    return Scaffold(
      appBar: AppBar(title: Text(isNew ? 'إضافة منتج' : 'تعديل منتج')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          GestureDetector(
            onTap: _pickSheet,
            child: Container(
              height: 200,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
              child: Stack(fit: StackFit.expand, children: [
                ProductImage(_img),
                Positioned(
                  bottom: 8,
                  left: 8,
                  child: FilledButton.tonalIcon(
                    onPressed: _pickSheet,
                    icon: const Icon(Icons.add_a_photo),
                    label: const Text('الصورة'),
                  ),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'اسم المنتج', border: OutlineInputBorder()),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _cat,
            decoration: const InputDecoration(labelText: 'القسم', border: OutlineInputBorder()),
            items: [for (final c in kCategories) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => _cat = v ?? _cat),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextFormField(
                controller: _price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: 'السعر ($kCurrency)', border: const OutlineInputBorder()),
                validator: (v) {
                  final n = double.tryParse(normDigits(v ?? ''));
                  return (n == null || n < 0) ? 'سعر غير صحيح' : null;
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                controller: _stock,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'الكمية', border: OutlineInputBorder()),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          TextFormField(
            controller: _sizes,
            decoration: const InputDecoration(
                labelText: 'المقاسات', hintText: 'S, M, L, XL', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _colors,
            decoration: const InputDecoration(
                labelText: 'الألوان', hintText: 'أسود، وردي، أبيض', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _desc,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'الوصف', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: Padding(padding: const EdgeInsets.all(12), child: Text(isNew ? 'إضافة' : 'حفظ التعديلات')),
          ),
        ]),
      ),
    );
  }
}
