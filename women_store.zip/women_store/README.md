# متجر الأزياء النسائية (Flutter)

## البناء على الكمبيوتر
1. ثبّت Flutter.
2. داخل مجلد المشروع: `flutter create . --platforms=android --project-name women_store --org com.store`
3. في android/app/build.gradle(.kts): اجعل minSdk = 23
4. في AndroidManifest.xml داخل <application>: أضف android:allowBackup="false"
5. `flutter pub get` ثم `flutter build apk --release --obfuscate --split-debug-info=build/symbols`
6. الملف: build/app/outputs/flutter-apk/app-release.apk

## البناء بدون كمبيوتر (GitHub Actions)
ارفع محتويات هذا المجلد كما هي إلى مستودع GitHub، ثم Actions > Build APK > Run workflow.
بعد دقائق حمّل app-release-apk من قسم Artifacts.

## ملاحظة أمان مهمة
البيانات مخزنة على الجهاز نفسه فقط. أول شخص يفتح التطبيق ينشئ حساب المالك.
